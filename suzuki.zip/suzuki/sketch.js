var sora;
var glitter;

function preload(){
  sora = loadImage('そらりん.jpg');
  glitter = loadImage('キラキラ.png');
}

function setup() {
 createCanvas(400, 400);
}

function draw() {
 background(205);
 //My dog
 image(sora, -50, -30, 500, 700);

 //text
 textFont('Helvetica');
 textSize(50);
 fill(255);
 stroke(0,128,128);
 text("I AM SORA. TWO YEARS OLD.", -5, 20, 100, 420);

 //glitter effect
 image(glitter, mouseX-100, mouseY-100);
}
