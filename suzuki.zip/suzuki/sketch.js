var ellx = 80;
var elly = 280;
var ellw = 20;
var ellh = 20;

var rec1x = 280;
var rec1y = 270;
var rec1w = 20;
var rec1h = 20;

var rec2x = 310;
var rec2y = 270;
var rec2w = 20;
var rec2h = 20;

var scx = 70;
var scy = 90;
var scw = 260;
var sch = 170;

var d;
var radius = 10;

var value1 = 100;
var value2 = 100;
var value3 = 100;

function setup() {
  createCanvas(400, 400);
  colorMode(RGB);
  background(250, 225, 177);
}

function draw(){
  //TV
  fill(186, 245, 241);
  rect(50, 70, width-100, 230);
  beginShape();
  vertex(120, 300);
  vertex(120, 320);
  vertex(80, 350);
  vertex(200, 330);
  vertex(320, 350);
  vertex(280, 320);
  vertex(280, 300);
  endShape();

  //ellipse button
  fill(255, 181, 186);
  ellipse(ellx, elly, ellw, ellh);

  //left rectangle button
  fill(191, 222, 158);
  rect(rec1x, rec1y, rec1w, rec1h);

  //right rectangle button
  fill(171, 158, 222);
  rect(rec2x, rec2y, rec2w, rec2h);

  //screen
  fill(value1, value2, value3);
  rect(scx, scy, scw, sch);
  if(keyIsPressed){
    if((key == 'p')&&(mouseX > rec2x)&&(mouseX < rec2x+rec2w)&&(mouseY > rec2y)&&(mouseY < rec2y+rec2h)){
      fill(171, 158, 222);
    }
  }
  rect(scx, scy, scw, sch);
 }

function mousePressed(){
  var d = dist(mouseX, mouseY, ellx, elly);
  if(d < radius){
    value1 = 255;
    value2 = 181;
    value3 = 186;
  }
    rect(scx, scy, scw, sch);
}

function mouseClicked(){
  if((mouseX > rec1x)&&(mouseX < rec1x+rec1w)&&(mouseY > rec1y)&&(mouseY < rec1y+rec1h)){
    value1 = 191;
    value2 = 222;
    value3 = 158;
  }
}
