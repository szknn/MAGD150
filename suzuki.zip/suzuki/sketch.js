let vid;

function setup(){
  noCanvas();

  vid = createVideo(
    ['Boston.mp4', 'Boston.ogv', 'Boston.webm'],
    vidLoad
  );

  vid.size(400, 400);
}

function vidLoad(){
  vid.loop();
  vid.showControls();
  vid.volume(10);
  vid.play();
}
